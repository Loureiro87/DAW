<?php
$f = fopen("datos.txt","a");
fputs($f,$_REQUEST['nombre'].
         " ".
         md5($_REQUEST['pass']).
         " ".
         $_REQUEST['anio'].
         "/".
         $_REQUEST['mes'].
         "/".
         $_REQUEST['dia'].
         "\n");
echo "OK";
?>