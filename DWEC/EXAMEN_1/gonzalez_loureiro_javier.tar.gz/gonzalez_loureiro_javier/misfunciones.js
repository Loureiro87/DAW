
function numeroPerfecto(numero){
    console.log(numero);
    var sumando ="";

    //
    for(let i = 0; i< numero; ++i){
        console.log(numero);
        //comprobamos si es divisible 
        if(numero%i == 0){
            //vamos sumando todos los divisibles 
            sumando =  i + i; 
            //cuando la suma de sus divisores es igual al numero termina y nos devuelve true o false
            if(sumando == numero){
                return true;
            }else if(i> numero){
                return fasle;
            }
            console.log(sumando +" Sumando");
        }
    }


    //return console.log(numero + "es correcto");
}